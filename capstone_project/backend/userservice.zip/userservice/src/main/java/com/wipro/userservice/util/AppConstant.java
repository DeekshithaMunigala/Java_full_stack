package com.wipro.userservice.util;

public class AppConstant {
    // Use the same secret as in API Gateway
    public static final String SECRET = "mySecretKeymySecretKeymySecretKeymySecretKey";
}
